import { env } from "cloudflare:workers";
import { initialSnapshot, disconnected, type Payload, type Snapshot, type SyncStatus } from "./timetable";
function db(){const binding=(env as unknown as {DB?:D1Database}).DB;if(!binding)throw new Error("课表存储暂时不可用，请稍后重试");return binding;}
export async function readPayload():Promise<Payload>{
 const rows=await db().prepare("SELECT key,value FROM campus_state WHERE key IN (?,?)").bind("snapshot","sync").all<{key:string,value:string}>();
 const map=Object.fromEntries(rows.results.map(r=>[r.key,JSON.parse(r.value)]));
 const stored=map.snapshot as Snapshot|undefined;
 // New screenshot revisions replace old course data, retaining durable edited bells.
 const snapshot=stored?.source===initialSnapshot.source?stored:{...initialSnapshot,bells:stored?.bells??initialSnapshot.bells};
 return {snapshot,sync:disconnected};
}
export async function writeSnapshot(snapshot:Snapshot,sync?:SyncStatus){const cmds=[db().prepare("INSERT INTO campus_state(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind("snapshot",JSON.stringify(snapshot))];if(sync)cmds.push(db().prepare("INSERT INTO campus_state(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind("sync",JSON.stringify(sync)));await db().batch(cmds);}
export async function syncCampus(_force=false):Promise<Payload>{
 throw new Error("自动同步已暂停，当前使用你提供的课表截图。");
}
