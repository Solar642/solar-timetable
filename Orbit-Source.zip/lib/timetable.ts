import { z } from "zod";
import { screenshotRevision, screenshotCourses, screenshotCoveredDates } from "./screenshot-data";
const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => Number.isFinite(Date.parse(v)) && new Date(v).toISOString().slice(0,10) === v);
const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
export const bellSchema = z.array(z.object({period:z.number().int().min(1).max(11),start:time,end:time}).refine(v => v.start < v.end)).max(11).refine(v=>new Set(v.map(x=>x.period)).size===v.length);
export const courseSchema = z.object({id:z.string().min(1).max(100),date:day,title:z.string().min(1).max(100),teacher:z.string().max(100),room:z.string().max(100),periods:z.array(z.number().int().min(1).max(11)).min(1).max(11),verified:z.boolean(),note:z.string().max(500).optional()});
export const snapshotSchema = z.object({semester:z.string().max(100),source:z.string().max(200),coveredDates:z.array(day).max(400),courses:z.array(courseSchema).max(2000),bells:bellSchema,complete:z.boolean()});
export type Course = z.infer<typeof courseSchema>;
export type Snapshot = z.infer<typeof snapshotSchema>;
export type SyncStatus = {state:"disconnected"|"connected"|"error";lastSuccess:string|null;lastAttempt:string|null;error:string|null;intervalMinutes:60};
export type Payload = {snapshot:Snapshot;sync:SyncStatus};
export const schoolBells:Snapshot["bells"] = [
 {period:1,start:"08:30",end:"09:10"},{period:2,start:"09:20",end:"10:00"},
 {period:3,start:"10:20",end:"11:00"},{period:4,start:"11:10",end:"11:50"},
 {period:5,start:"13:10",end:"13:50"},{period:6,start:"14:00",end:"14:40"},
 {period:7,start:"14:50",end:"15:30"},{period:8,start:"15:40",end:"16:20"},
 {period:9,start:"16:30",end:"17:10"},{period:10,start:"18:30",end:"19:30"}
];
export const initialSnapshot:Snapshot = {semester:"2026–2027 · 第一学期",source:screenshotRevision,coveredDates:screenshotCoveredDates,complete:false,bells:schoolBells,courses:screenshotCourses};
export const disconnected:SyncStatus={state:"disconnected",lastSuccess:null,lastAttempt:null,error:null,intervalMinutes:60};
export const initialPayload:Payload={snapshot:initialSnapshot,sync:disconnected};
export function addDays(date:string,n:number){const d=new Date(date+"T00:00:00Z");d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
export function monday(date:string){const d=new Date(date+"T00:00:00Z");return addDays(date,-((d.getUTCDay()+6)%7));}
export function shanghaiDate(date=new Date()){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Shanghai",year:"numeric",month:"2-digit",day:"2-digit"}).format(date);}
export function courseTime(course:Course,bells:Snapshot["bells"]){const slots=course.periods.map(p=>bells.find(b=>b.period===p));if(slots.some(x=>!x))return null;return {start:slots[0]!.start,end:slots[slots.length-1]!.end};}
export function sortedCourses(snapshot:Snapshot,date:string){return snapshot.courses.filter(c=>c.date===date).sort((a,b)=>Math.min(...a.periods)-Math.min(...b.periods));}
export function semesterWeek(date:string){return Math.floor((Date.parse(date+"T00:00:00Z")-Date.parse("2026-08-31T00:00:00Z"))/604800000)+1;}
