import type { Course } from "./timetable";

// Rectangles: 1–2, 3–4, 5, 6–7, 8–9. Half a paired row = one period.
// User-provided fixed metadata takes precedence over screenshot room/teacher text.
export const screenshotRevision = "截图录入 v3 · 第6–19周";
export const catalog = {
 electric:{title:"电工基础",teacher:"熊曼子",room:"实训楼1 · 301B"},
 ethics:{title:"思想道德与法治",teacher:"邓倩",room:"教学楼1 · 402"},
 sport:{title:"体育",teacher:"刘瑶",room:"操场3"},
 safety:{title:"实训安全教育",teacher:"韩鹰飞",room:"实训楼1 · 516"},
 meeting:{title:"主题班会",teacher:"陈苗苗",room:"随上一节课 · 待确认"},
 computer:{title:"信息技术基础",teacher:"叶似男",room:"图书馆 · 507B"},
 thought:{title:"习近平新时代中国特色社会主义思想概论",teacher:"张歆宇",room:"实训楼4 · 307"},
 electronics:{title:"电子技术",teacher:"熊曼子",room:"实训楼1 · 302B"},
 career:{title:"职业发展与就业指导",teacher:"李婷婷",room:"教学楼1 · 403"},
 practice:{title:"电工实训",teacher:"邓子祥",room:"实训楼2 · 210"},
 quality:{title:"质量管控基础",teacher:"李芬",room:"教学楼3 · 101"},
 policy:{title:"形势与政策",teacher:"王有农、聂碧娟",room:"教学楼2 · 101"},
 ai:{title:"人工智能通识课",teacher:"叶似男",room:"图书馆 · 507B"},
} as const;
type Key = keyof typeof catalog;
type Entry = [day:number, key:Key, first:number, last:number];
const normal:Entry[] = [[0,"electric",1,2],[0,"thought",3,4],[0,"electronics",6,7],[1,"electronics",3,4],[1,"computer",6,9],[3,"electric",3,4],[3,"ethics",6,7],[3,"sport",8,9]];
export const screenshotWeeks:Record<number,{monday:string;file:string;entries:Entry[]}> = {
 6:{monday:"2026-10-05",file:"3016.jpeg",entries:[[3,"electric",3,4],[3,"ethics",6,7],[3,"sport",8,9],[4,"safety",6,7],[4,"meeting",8,8]]},
 7:{monday:"2026-10-12",file:"用户确认无排课",entries:[]},
 8:{monday:"2026-10-19",file:"3017.jpeg",entries:[[6,"computer",6,9]]},
 9:{monday:"2026-10-26",file:"3018.jpeg",entries:[...normal,[2,"career",1,2],[4,"sport",6,7],[6,"computer",6,9]]},
 10:{monday:"2026-11-02",file:"3019.jpeg",entries:[...normal,[0,"meeting",8,8],[2,"career",1,2]]},
 11:{monday:"2026-11-09",file:"3020.jpeg",entries:[...normal,[2,"computer",1,4]]},
 12:{monday:"2026-11-16",file:"3021.jpeg",entries:[...Array.from({length:5},(_,d):Entry[]=>[[d,"practice",1,2],[d,"practice",3,4]]).flat(),[0,"practice",6,7],[1,"practice",6,7],[0,"meeting",8,8],[3,"ethics",6,7]]},
 13:{monday:"2026-11-23",file:"3022.jpeg",entries:[...normal,[2,"quality",3,4],[4,"policy",3,4]]},
 14:{monday:"2026-11-30",file:"3023.jpeg",entries:[...normal,[1,"meeting",2,2],[2,"quality",3,4],[4,"policy",3,4],[4,"ai",6,9]]},
 15:{monday:"2026-12-07",file:"3024.jpeg",entries:[...normal,[2,"policy",1,2],[2,"quality",3,4],[4,"ai",6,9]]},
 16:{monday:"2026-12-14",file:"3025.jpeg",entries:[...normal,[1,"ethics",1,2],[2,"policy",1,2],[2,"quality",3,4],[3,"meeting",2,2]]},
 17:{monday:"2026-12-21",file:"3026.jpeg",entries:[...normal,[2,"quality",3,4]]},
 18:{monday:"2026-12-28",file:"3027.jpeg",entries:[...normal,[1,"meeting",2,2],[2,"quality",3,4]]},
 19:{monday:"2027-01-04",file:"3028.jpeg",entries:[[0,"thought",3,4],[1,"computer",6,9],[2,"quality",3,4]]},
};
function dateOffset(date:string,n:number){const d=new Date(`${date}T00:00:00Z`);d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
export const screenshotCoveredDates = Object.values(screenshotWeeks).flatMap(w=>Array.from({length:7},(_,i)=>dateOffset(w.monday,i)));
export const screenshotCourses:Course[] = Object.entries(screenshotWeeks).flatMap(([week,w])=>w.entries.map(([day,key,first,last],i):Course=>({
 id:`w${week}-${day}-${key}-${first}-${i}`,date:dateOffset(w.monday,day),...catalog[key],periods:Array.from({length:last-first+1},(_,j)=>first+j),verified:true,
}))).sort((a,b)=>a.date.localeCompare(b.date)||a.periods[0]-b.periods[0]);
const confirmedMeetingRooms:Record<number,string> = {14:"实训楼1 · 305A",16:"教学楼1 · 102",18:"实训楼1 · 510"};
for(const c of screenshotCourses){if(c.title!==catalog.meeting.title)continue;
 const week=Number(c.id.match(/^w(\d+)-/)![1]);
 if(confirmedMeetingRooms[week]){c.room=confirmedMeetingRooms[week];continue;}
 const previous=screenshotCourses.filter(x=>x.date===c.date&&x.id!==c.id&&Math.max(...x.periods)<c.periods[0]).at(-1);
 if(previous){c.room=previous.room;c.note=`随上一节「${previous.title}」的地点。`;}
 else c.note="班会之前当天没有已排课程，暂时无法确定所指的上一节课，请确认地点。";
}
