"use client";
import { useEffect, useState } from "react";
export default function OfflineAccess({localOnly=false}:{localOnly?:boolean}){
 const [status,setStatus]=useState("离线入口");const [updated,setUpdated]=useState(false);
 useEffect(()=>{if(location.protocol==="file:"){setStatus("本地离线版");return;}if(!("serviceWorker" in navigator)){setStatus("离线缓存不可用");return;}let live=true;const alreadyControlled=!!navigator.serviceWorker.controller;const changed=()=>{if(alreadyControlled&&live)setUpdated(true);};navigator.serviceWorker.addEventListener("controllerchange",changed);
 const prepare=async()=>{try{if(navigator.onLine)await navigator.serviceWorker.register("/sw.js",{scope:"/"});else if(!await navigator.serviceWorker.getRegistration("/")){if(live)setStatus("请联网保存一次");return;}await navigator.serviceWorker.ready;const cached=await caches.match("/offline");if(live)setStatus(cached?"离线已保存":"请联网保存一次");}catch{if(live)setStatus("离线保存失败");}};
 void prepare();return()=>{live=false;navigator.serviceWorker.removeEventListener("controllerchange",changed);};},[]);
 if(updated)return <button className="text-button" onClick={()=>location.reload()}>新版已就绪 · 点击更新</button>;
 return localOnly?<span className="text-button" role="status">{status}</span>:<a className="text-button" href="/offline">{status}</a>;
}
