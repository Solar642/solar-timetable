import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Solar · 今日课表",
  description: "课程、地点与作息，打开就能看。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
