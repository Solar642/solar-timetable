export async function PUT(){return Response.json({error:"请在课表页面设置作息，设置仅保存在你自己的设备上"},{status:403});}
