// Diagnose the actual school's HTTPS entrance from the hosted runtime.
// The destination is fixed; this is not an arbitrary proxy. No credentials are sent.
export async function GET(request:Request){
 try{
  const transport=new URL(request.url).searchParams.get("transport")==="http"?"http":"https";
  const response=await fetch(`${transport}://jw.wgxy.edu.cn/jsxsd/framework/xsMainV.htmlx`,{redirect:"follow",signal:AbortSignal.timeout(15000),headers:{Accept:"text/html"}});
  const text=(await response.text()).slice(0,180000);
  const title=text.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.replace(/<[^>]+>/g,"").trim()??"";
  // Only expose unfilled public form structure; never expose authenticated data.
  const hasPassword=/<input\b[^>]*type\s*=\s*["']?password/i.test(text);
  const publicLogin=hasPassword?text.replace(/<input\b[^>]*>/gi,tag=>tag.replace(/\bvalue\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi,"value=\"\"")):null;
  return Response.json({reachable:response.ok,status:response.status,url:response.url,title,hasLoginForm:hasPassword,loginHtml:publicLogin},{headers:{"Cache-Control":"no-store"}});
 }catch{return Response.json({reachable:false,error:"网页后台暂时无法连接学校教务系统",status:null},{status:502,headers:{"Cache-Control":"no-store"}});}
}
