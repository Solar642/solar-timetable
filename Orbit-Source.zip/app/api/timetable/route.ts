import { readPayload } from "@/lib/campus-store";
export async function GET(){try{return Response.json(await readPayload(),{headers:{"Cache-Control":"no-store"}});}catch{return Response.json({error:"课表暂时加载失败，请重试"},{status:503});}}
