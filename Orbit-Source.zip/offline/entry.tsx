import React from "react";
import { createRoot } from "react-dom/client";
import Campus from "../app/campus";
import "../app/globals.css";
createRoot(document.getElementById("root")!).render(<Campus localOnly/>);
